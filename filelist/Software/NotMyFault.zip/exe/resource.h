//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by notmyfault.rc
//
#define IDC_BUFFEROVERFLOW              1000
#define IDC_WILDPOINTER                 1001
#define IDC_DEADLOCK                    1002
#define IDC_STACKTRASH                  1003
#define IDC_HANG                        1004
#define IDC_PAGEFAULT                   1005
#define IDC_IRQL                        1006
#define IDC_LEAK                        1007
#define IDC_LEAK_PAGE                   1007
#define IDC_HANGIRP                     1008
#define IDC_LEAK_NONPAGE                1009
#define IDC_LEAKMB                      1010
#define IDC_COLOR                       1012
#define IDC_RADIOFG                     1013
#define IDC_RADIOBG                     1014
#define IDC_PREVIEW                     1016
#define IDC_CRASH_OK                    1017
#define IDC_HANG_OK                     1018
#define IDC_LEAK_OK                     1019
#define IDC_STACKOVERFLOW               1020
#define IDC_BREAKPOINT                  1021
#define IDC_DOUBLEFREE                  1022
#define IDC_PAGED_STATUS                1023
#define IDC_NONPAGED_STATUS             1024
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1025
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
